/**
 * Edit {{EntityName}} Component
 *
 * Wrapper around {{EntityName}}Form for inline editing experiences.
 */

import { Card } from "@truths/ui";
import { cn } from "@truths/ui/lib/utils";
import {{{EntityName}}Form, type {{EntityName}}FormData } from "./{{entity-name}}-form";
import type {{{EntityName}}, Update{{EntityName}}Input } from "../types";

export interface Edit{{EntityName}}Props {
  className?: string;
  {{entityName}}: {{EntityName}};
  onSubmit: (id: string, input: Update{{EntityName}}Input) => Promise<void> | void;
  isLoading?: boolean;
}

export function Edit{{EntityName}}({
  className,
  {{entityName}},
  onSubmit,
  isLoading = false,
}: Edit{{EntityName}}Props) {
  const handleSubmit = async (data: {{EntityName}}FormData) => {
    const payload: Update{{EntityName}}Input = {
{{#fields}}
      {{name}}: {{updateValue}},
{{/fields}}
    };

    await onSubmit({{entityName}}.id, payload);
  };

  const formDefaultValues: Partial<{{EntityName}}FormData> = {
{{#fields}}
    {{name}}: {{entityName}}.{{name}}{{#if isDate}} ? {{entityName}}.{{name}} : ""{{else}}{{#if isBoolean}} ?? false{{else}}{{#if isNumber}} ?? 0{{else}}{{#if isString}} ?? ""{{/if}}{{/if}}{{/if}}{{/if}},
{{/fields}}
  };

  return (
    <Card className={cn("p-6", className)}>
      <{{EntityName}}Form
        onSubmit={handleSubmit}
        isLoading={isLoading}
        defaultValues={formDefaultValues}
        mode="edit"
      />
    </Card>
  );
}

