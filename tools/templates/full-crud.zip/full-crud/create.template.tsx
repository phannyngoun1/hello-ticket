/**
 * Create {{EntityName}} Component
 *
 * Lightweight wrapper that renders the shared {{EntityName}}Form for inline usage.
 */

import { Card } from "@truths/ui";
import { cn } from "@truths/ui/lib/utils";
import {{{EntityName}}Form, type {{EntityName}}FormData } from "./{{entity-name}}-form";
import type { Create{{EntityName}}Input } from "../types";

export interface Create{{EntityName}}Props {
  className?: string;
  onSubmit: (data: Create{{EntityName}}Input) => Promise<void> | void;
  isLoading?: boolean;
  defaultValues?: Partial<{{EntityName}}FormData>;
}

export function Create{{EntityName}}({
  className,
  onSubmit,
  isLoading = false,
  defaultValues,
}: Create{{EntityName}}Props) {
  const handleSubmit = async (data: {{EntityName}}FormData) => {
    const payload: Create{{EntityName}}Input = {
{{#fields}}
      {{name}}: {{createValue}},
{{/fields}}
    };

    await onSubmit(payload);
  };

  return (
    <Card className={cn("p-6", className)}>
      <{{EntityName}}Form
        onSubmit={handleSubmit}
        isLoading={isLoading}
        defaultValues={defaultValues}
        mode="create"
      />
    </Card>
  );
}

