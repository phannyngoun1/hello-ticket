/**
 * {{EntityName}} Service
 *
 * Encapsulates all {{entity-name}} API operations and data transformations.
 */

import {{{EntityName}}, Create{{EntityName}}Input, Update{{EntityName}}Input } from "../types";
import { ServiceConfig, PaginatedResponse } from "@truths/shared";

interface {{EntityName}}DTO {
  id: string;
{{#fields}}
  {{name}}{{#if isOptional}}?{{/if}}: {{dtoType}};
{{/fields}}
  created_at?: string;
  updated_at?: string;
}

function transform{{EntityName}}(dto: {{EntityName}}DTO): {{EntityName}} {
  return {
    id: dto.id,
{{#fields}}
    {{name}}: {{serviceTransformValue}},
{{/fields}}
    created_at: dto.created_at,
    updated_at: dto.updated_at,
    createdAt: dto.created_at ? new Date(dto.created_at) : new Date(),
    updatedAt: dto.updated_at ? new Date(dto.updated_at) : undefined,
  };
}

function transformToBackend(input: Create{{EntityName}}Input | Update{{EntityName}}Input): Record<string, unknown> {
  const payload: Record<string, unknown> = {};

{{#fields}}
  if ("{{name}}" in input && input.{{name}} !== undefined) {
    payload.{{name}} = {{backendValue}};
  }
{{/fields}}

  return payload;
}

interface {{EntityName}}Endpoints extends Record<string, string> {
  "{{entity-plural}}": string;
}

export type {{EntityName}}ServiceConfig = ServiceConfig<{{EntityName}}Endpoints>;

export class {{EntityName}}Service {
  private config: {{EntityName}}ServiceConfig;

  constructor(config: {{EntityName}}ServiceConfig) {
    this.config = config;
  }

  private getEndpoint() {
    return this.config.endpoints?.["{{entity-plural}}"] || "/api/v1/{{packageName}}/{{entity-plural}}";
  }

  async fetch{{EntityPlural}}(params?: {
    skip?: number;
    limit?: number;
    search?: string;
    [key: string]: unknown;
  }): Promise<PaginatedResponse<{{EntityName}}>> {
    const { apiClient } = this.config;
    const endpoint = this.getEndpoint();

    const queryParams = new URLSearchParams();
    if (params?.skip !== undefined) queryParams.append("skip", params.skip.toString());
    if (params?.limit !== undefined) queryParams.append("limit", params.limit.toString());
    if (params?.search) queryParams.append("search", params.search);

    const url = queryParams.toString() ? `${endpoint}?${queryParams.toString()}` : endpoint;
    const data = await apiClient.get<{ items?: {{EntityName}}DTO[]; total?: number; total_pages?: number; page?: number; page_size?: number }>(url, {
      requiresAuth: true,
    });

    return {
      data: (data.items ?? []).map(transform{{EntityName}}),
      pagination: {
        page: data.page ?? Math.floor((params?.skip || 0) / (params?.limit || 50)) + 1,
        pageSize: data.page_size ?? params?.limit ?? 50,
        total: data.total ?? 0,
        totalPages: data.total_pages ?? 0,
      },
    };
  }

  async fetch{{EntityName}}(id: string): Promise<{{EntityName}}> {
    const { apiClient } = this.config;
    const endpoint = this.getEndpoint();
    const data = await apiClient.get<{{EntityName}}DTO>(`${endpoint}/${id}`, {
      requiresAuth: true,
    });
    return transform{{EntityName}}(data);
  }

  async create{{EntityName}}(input: Create{{EntityName}}Input): Promise<{{EntityName}}> {
    const { apiClient } = this.config;
    const endpoint = this.getEndpoint();
    const payload = transformToBackend(input);
    const data = await apiClient.post<{{EntityName}}DTO>(endpoint, payload, {
      requiresAuth: true,
    });
    return transform{{EntityName}}(data);
  }

  async update{{EntityName}}(id: string, input: Update{{EntityName}}Input): Promise<{{EntityName}}> {
    const { apiClient } = this.config;
    const endpoint = this.getEndpoint();
    const payload = transformToBackend(input);
    const data = await apiClient.put<{{EntityName}}DTO>(`${endpoint}/${id}`, payload, {
      requiresAuth: true,
    });
    return transform{{EntityName}}(data);
  }

  async delete{{EntityName}}(id: string): Promise<void> {
    const { apiClient } = this.config;
    const endpoint = this.getEndpoint();
    await apiClient.delete(`${endpoint}/${id}`, {
      requiresAuth: true,
    });
  }
}

export type {{EntityName}}EndpointsMap = {{EntityName}}Endpoints;
