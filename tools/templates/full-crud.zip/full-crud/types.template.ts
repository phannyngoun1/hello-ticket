/**
 * {{EntityName}} Types
 */
export interface {{EntityName}} {
    id: string;
{{#fields}}
    {{name}}{{#if isOptional}}?{{/if}}: {{modelType}};
{{/fields}}
    created_at?: string;
    updated_at?: string;
    createdAt: Date;
    updatedAt?: Date;
{{#if hasStatus}}
    status: 'active' | 'inactive';
{{/if}}
}

export interface Create{{EntityName}}Input {
{{#fields}}
    {{name}}{{#unless required}}?{{/unless}}: {{createType}};
{{/fields}}
}

export interface Update{{EntityName}}Input {
{{#fields}}
    {{name}}?: {{updateType}};
{{/fields}}
}

export interface {{EntityName}}Filter {
    search?: string;
{{#if hasStatus}}
    status?: {{EntityName}}['status'];
{{/if}}{{#filterParams}}
    {{name}}?: {{type}};
{{/filterParams}}
}

