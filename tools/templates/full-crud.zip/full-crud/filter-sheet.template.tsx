/**
 * {{EntityName}} Filter Sheet Component
 *
 * Advanced filter sheet for {{EntityName}}List that allows filtering by multiple criteria.
 */

import { useState, useEffect } from "react";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
  SheetFooter,
  Button,
  Input,
  Label,
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@truths/ui";
import {{{EntityName}}Filter } from "../types";

export interface {{EntityName}}FilterSheetProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  filter?: {{EntityName}}Filter;
  onApply: (filter: {{EntityName}}Filter) => void;
  onReset?: () => void;
}

export function {{EntityName}}FilterSheet({
  open,
  onOpenChange,
  filter: initialFilter = {},
  onApply,
  onReset,
}: {{EntityName}}FilterSheetProps) {
  const [filter, setFilter] = useState<{{EntityName}}Filter>(initialFilter);

  // Update internal state when prop changes
  useEffect(() => {
    setFilter(initialFilter);
  }, [initialFilter]);

  const handleApply = () => {
    onApply(filter);
    onOpenChange(false);
  };

  const handleReset = () => {
    const emptyFilter: {{EntityName}}Filter = {};
    setFilter(emptyFilter);
    if (onReset) {
      onReset();
    } else {
      onApply(emptyFilter);
    }
    onOpenChange(false);
  };

  const handleCancel = () => {
    setFilter(initialFilter);
    onOpenChange(false);
  };

  const updateFilter = <K extends keyof {{EntityName}}Filter>(
    key: K,
    value: {{EntityName}}Filter[K] | undefined
  ) => {
    setFilter((prev) => ({ ...prev, [key]: value }));
  };

  const hasActiveFilters = Object.values(filter).some(
    (value) => value !== undefined && value !== ""
  );

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent
        side="right"
        className="w-[700px] sm:w-[800px] flex flex-col p-0 h-full"
      >
        <SheetHeader className="px-4 pt-4 pb-3 flex-shrink-0">
          <SheetTitle className="text-base">Advanced Filters</SheetTitle>
          <SheetDescription className="text-xs">
            Add multiple criteria to filter {{entity-plural}}. All filters are combined with AND logic.
          </SheetDescription>
        </SheetHeader>

        <div className="flex-1 overflow-y-auto px-4 min-h-0">
          <div className="space-y-4 pb-4">
            {{#if hasRole}}
            {/* Role Filter */}
            <div className="space-y-1.5">
              <Label htmlFor="role" className="text-xs">
                Role
              </Label>
              <Select
                value={filter.role || "all"}
                onValueChange={(value) => {
                  if (value === "all") {
                    updateFilter("role", undefined);
                  } else {
                    updateFilter("role", value);
                  }
                }}
              >
                <SelectTrigger id="role" className="h-8 text-xs">
                  <SelectValue placeholder="All roles" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All roles</SelectItem>
                  <SelectItem value="admin">Admin</SelectItem>
                  <SelectItem value="user">User</SelectItem>
                </SelectContent>
              </Select>
            </div>
            {{/if}}

            {{#if hasStatus}}
            {/* Status Filter */}
            <div className="space-y-1.5">
              <Label htmlFor="status" className="text-xs">
                Status
              </Label>
              <Select
                value={filter.status || "all"}
                onValueChange={(value) => {
                  if (value === "all") {
                    updateFilter("status", undefined);
                  } else {
                    updateFilter("status", value as {{EntityName}}["status"]);
                  }
                }}
              >
                <SelectTrigger id="status" className="h-8 text-xs">
                  <SelectValue placeholder="All statuses" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All statuses</SelectItem>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="inactive">Inactive</SelectItem>
                  {{#if hasSuspendedStatus}}
                  <SelectItem value="suspended">Suspended</SelectItem>
                  {{/if}}
                  {{#if hasPendingStatus}}
                  <SelectItem value="pending">Pending</SelectItem>
                  {{/if}}
                </SelectContent>
              </Select>
            </div>
            {{/if}}

            {{#filterParams}}
            {{#if isDate}}
            {/* {{label}} Filter */}
            <div className="space-y-1.5">
              <Label htmlFor="{{name}}" className="text-xs">
                {{label}}
              </Label>
              <Input
                id="{{name}}"
                type="date"
                className="h-8 text-xs"
                value={
                  filter.{{name}}
                    ? new Date(filter.{{name}}).toISOString().split("T")[0]
                    : ""
                }
                onChange={(e) =>
                  updateFilter(
                    "{{name}}",
                    e.target.value ? new Date(e.target.value) : undefined
                  )
                }
              />
            </div>
            {{/if}}
            {{/filterParams}}

            {{#if hasDateRange}}
            {/* Date Range Filters */}
            <div className="space-y-3">
              <Label className="text-xs">Created Date Range</Label>

              <div className="space-y-1.5">
                <Label
                  htmlFor="createdAfter"
                  className="text-xs text-muted-foreground"
                >
                  Created After
                </Label>
                <Input
                  id="createdAfter"
                  type="date"
                  className="h-8 text-xs"
                  value={
                    filter.createdAfter
                      ? new Date(filter.createdAfter).toISOString().split("T")[0]
                      : ""
                  }
                  onChange={(e) =>
                    updateFilter(
                      "createdAfter",
                      e.target.value ? new Date(e.target.value) : undefined
                    )
                  }
                />
              </div>

              <div className="space-y-1.5">
                <Label
                  htmlFor="createdBefore"
                  className="text-xs text-muted-foreground"
                >
                  Created Before
                </Label>
                <Input
                  id="createdBefore"
                  type="date"
                  className="h-8 text-xs"
                  value={
                    filter.createdBefore
                      ? new Date(filter.createdBefore).toISOString().split("T")[0]
                      : ""
                  }
                  onChange={(e) =>
                    updateFilter(
                      "createdBefore",
                      e.target.value ? new Date(e.target.value) : undefined
                    )
                  }
                />
              </div>
            </div>
            {{/if}}
          </div>
        </div>

        <SheetFooter className="px-4 py-3 border-t bg-background flex-shrink-0">
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={handleCancel}
              className="flex-1 h-8 text-xs"
            >
              Cancel
            </Button>
            {hasActiveFilters && (
              <Button
                variant="outline"
                size="sm"
                onClick={handleReset}
                className="flex-1 h-8 text-xs"
              >
                Reset
              </Button>
            )}
            <Button
              size="sm"
              onClick={handleApply}
              className="flex-1 h-8 text-xs"
            >
              Apply
            </Button>
          </div>
        </SheetFooter>
      </SheetContent>
    </Sheet>
  );
}

