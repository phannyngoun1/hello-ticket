/**
 * {{EntityName}} Detail Component
 *
 * Display detailed information about a {{entity-name}} with optional edit and activity views.
 */

import React, { useMemo, useState } from "react";
import {
  Button,
  Card,
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  Tabs,
  {{#if hasStatusActions}}DropdownMenuSeparator,{{/if}}
  {{#if hasStatus}}Badge,{{/if}}
} from "@truths/ui";
import { cn } from "@truths/ui/lib/utils";
import {
  Edit,
  MoreVertical,
  Info,
  Database,
  {{#if hasStatusActions}}Lock, Unlock, CheckCircle, XCircle,{{/if}}
} from "lucide-react";
import {{{EntityName}}} from "../types";

export interface {{EntityName}}DetailProps {
  className?: string;
  {{entityVar}}?: {{EntityName}};
  loading?: boolean;
  error?: Error | null;
  {{#if hasActivity}}
  activities?: any[];
  {{/if}}
  showActivity?: boolean;
  showMetadata?: boolean;
  editable?: boolean;
  onEdit?: ({{entityVar}}: {{EntityName}}) => void;
  {{#if hasStatusActions}}
  onActivate?: ({{entityVar}}: {{EntityName}}) => Promise<void>;
  onDeactivate?: ({{entityVar}}: {{EntityName}}) => Promise<void>;
  onLock?: ({{entityVar}}: {{EntityName}}) => Promise<void>;
  onUnlock?: ({{entityVar}}: {{EntityName}}) => Promise<void>;
  {{/if}}
  customActions?: ({{entityVar}}: {{EntityName}}) => React.ReactNode;
}

export function {{EntityName}}Detail({
  className,
  {{entityVar}},
  loading = false,
  error = null,
  {{#if hasActivity}}
  activities = [],
  {{/if}}
  showMetadata = false,
  editable = true,
  onEdit,
  {{#if hasStatusActions}}
  onActivate,
  onDeactivate,
  onLock,
  onUnlock,
  {{/if}}
  customActions,
}: {{EntityName}}DetailProps) {
  const [activeTab, setActiveTab] = useState<"profile" | "metadata">("profile");
  {{#if hasStatusActions}}
  const [activateConfirmOpen, setActivateConfirmOpen] = useState(false);
  const [deactivateConfirmOpen, setDeactivateConfirmOpen] = useState(false);
  const [lockConfirmOpen, setLockConfirmOpen] = useState(false);
  const [unlockConfirmOpen, setUnlockConfirmOpen] = useState(false);
  {{/if}}

  // All hooks must be called before any early returns
  {{#if hasDisplayName}}
  const get{{EntityName}}DisplayName = () => {
    {{#fields}}
    {{#if isDisplayField}}
    {{#if isFirst}}
    return {{entityVar}}?.{{name}} || {{entityVar}}?.id || "";
    {{/if}}
    {{/if}}
    {{/fields}}
    return {{entityVar}}?.id || "";
  };
  {{/if}}

  const displayName = useMemo(
    () =>
      {{entityVar}}
        ? {{#if hasDisplayName}}get{{EntityName}}DisplayName(){{else}}{{entityVar}}.id{{/if}}
        : "",
    [{{entityVar}}{{#if hasDisplayName}}, {{entityVar}}?.{{#fields}}{{#if isDisplayField}}{{#if isFirst}}{{name}}{{/if}}{{/if}}{{/fields}}{{/if}}]
  );

  {{#if hasStatus}}
  const is{{EntityName}}Active = {{entityVar}}?.status === "active";
  {{#if hasLockedUntil}}
  const is{{EntityName}}Locked =
    {{entityVar}}?.lockedUntil && new Date({{entityVar}}.lockedUntil) > new Date();
  {{/if}}
  {{/if}}

  const formatDate = (value?: Date | string) => {
    if (!value) return "N/A";
    const date = value instanceof Date ? value : new Date(value);
    return Number.isNaN(date.getTime()) ? String(value) : date.toLocaleString();
  };

  const formatFieldValue = (value: unknown) => {
    if (value === null || value === undefined) return "N/A";
    if (value instanceof Date) {
      return value.toLocaleString();
    }
    if (typeof value === "string") {
      const trimmed = value.trim();
      if (!trimmed) return "N/A";
      const potentialDate = new Date(trimmed);
      if (!Number.isNaN(potentialDate.getTime())) {
        return potentialDate.toLocaleString();
      }
      return trimmed;
    }
    if (typeof value === "number" || typeof value === "boolean") {
      return String(value);
    }
    try {
      return JSON.stringify(value);
    } catch {
      return String(value);
    }
  };

  if (loading) {
    return (
      <Card className={cn("p-6", className)}>
        <div className="flex items-center justify-center py-12">
          <div className="text-muted-foreground">Loading...</div>
        </div>
      </Card>
    );
  }

  if (error) {
    return (
      <Card className={cn("p-6", className)}>
        <div className="flex items-center justify-center py-12">
          <div className="text-destructive">Error: {error.message}</div>
        </div>
      </Card>
    );
  }

  if (!{{entityVar}}) {
    return (
      <Card className={cn("p-6", className)}>
        <div className="flex items-center justify-center py-12">
          <div className="text-muted-foreground">No {{entity-name}} selected</div>
        </div>
      </Card>
    );
  }

  const hasMetadata = showMetadata;

  return (
    <Card className={cn("p-6", className)}>
      <div>
        {/* Header */}
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-4">
            <div className="flex h-20 w-20 items-center justify-center rounded-lg bg-primary/10">
              {{#if hasIcon}}
              <{{iconName}} className="h-10 w-10 text-primary" />
              {{else}}
              <Info className="h-10 w-10 text-primary" />
              {{/if}}
            </div>
            <div>
              <h2 className="text-xl font-semibold">{displayName}</h2>
              {{#fields}}
              {{#if isCodeField}}
              {{{entityVar}}.{{name}} && (
                <p className="text-sm text-muted-foreground mt-1">
                  {{label}}: {{{entityVar}}.{{name}}}
                </p>
              )}
              {{/if}}
              {{/fields}}
              {{#fields}}
              {{#unless isCodeField}}
              {{#unless isDisplayField}}
              {{#if isFirst}}
              {{#unless isId}}
              {{#unless isDate}}
              {{#unless isStatus}}
              <p className="text-sm text-muted-foreground mt-1">
                ID: {{{entityVar}}.id}
              </p>
              {{/unless}}
              {{/unless}}
              {{/unless}}
              {{/if}}
              {{/unless}}
              {{/unless}}
              {{/fields}}
              {{#if hasStatus}}
              <div className="mt-2 flex items-center gap-2">
                <Badge variant={is{{EntityName}}Active ? "default" : "secondary"}>
                  {is{{EntityName}}Active ? "Active" : "Inactive"}
                </Badge>
              </div>
              {{/if}}
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2">
              {customActions?.({{entityVar}})}
            </div>
            <div>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon" aria-label="Actions">
                    <MoreVertical className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  {editable && onEdit && (
                    <DropdownMenuItem onClick={() => onEdit({{entityVar}})}>
                      <Edit className="mr-2 h-3.5 w-3.5" /> Edit {{entity-name}}
                    </DropdownMenuItem>
                  )}

                  {{#if hasStatusActions}}
                  {((editable && onEdit) || customActions) &&
                    (onActivate || onDeactivate || onLock || onUnlock) && (
                      <DropdownMenuSeparator />
                    )}

                  {(onActivate || onDeactivate) && (
                    <DropdownMenuItem
                      onClick={() => {
                        if (is{{EntityName}}Active && onDeactivate) {
                          setDeactivateConfirmOpen(true);
                        } else if (!is{{EntityName}}Active && onActivate) {
                          setActivateConfirmOpen(true);
                        }
                      }}
                    >
                      {is{{EntityName}}Active ? (
                        <>
                          <XCircle className="mr-2 h-3.5 w-3.5" /> Deactivate
                        </>
                      ) : (
                        <>
                          <CheckCircle className="mr-2 h-3.5 w-3.5" /> Activate
                        </>
                      )}
                    </DropdownMenuItem>
                  )}

                  {(onLock || onUnlock) && (
                    <DropdownMenuItem
                      onClick={() => {
                        {{#if hasLockedUntil}}
                        if (is{{EntityName}}Locked && onUnlock && is{{EntityName}}Active) {
                          setUnlockConfirmOpen(true);
                        } else if (!is{{EntityName}}Locked && onLock && is{{EntityName}}Active) {
                          setLockConfirmOpen(true);
                        }
                        {{else}}
                        if (onLock && is{{EntityName}}Active) {
                          setLockConfirmOpen(true);
                        } else if (onUnlock && is{{EntityName}}Active) {
                          setUnlockConfirmOpen(true);
                        }
                        {{/if}}
                      }}
                    >
                      {{#if hasLockedUntil}}
                      {is{{EntityName}}Locked ? (
                        <>
                          <Unlock className="mr-2 h-3.5 w-3.5" /> Unlock
                        </>
                      ) : (
                        <>
                          <Lock className="mr-2 h-3.5 w-3.5" /> Lock
                        </>
                      )}
                      {{else}}
                      <Lock className="mr-2 h-3.5 w-3.5" /> Lock/Unlock
                      {{/if}}
                    </DropdownMenuItem>
                  )}
                  {{/if}}

                  {customActions && customActions({{entityVar}})}
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <Tabs
          value={activeTab}
          onValueChange={(value) => setActiveTab(value as any)}
        >
          <div className="border-b mb-4">
            <div className="flex gap-4">
              <button
                className={cn(
                  "border-b-2 px-4 py-2 text-sm font-medium transition-colors",
                  activeTab === "profile"
                    ? "border-primary text-primary"
                    : "border-transparent text-muted-foreground hover:text-foreground"
                )}
                onClick={() => setActiveTab("profile")}
              >
                <span className="flex items-center gap-2">
                  <Info className="h-4 w-4" />
                  Profile
                </span>
              </button>
              {hasMetadata && (
                <button
                  className={cn(
                    "border-b-2 px-4 py-2 text-sm font-medium transition-colors",
                    activeTab === "metadata"
                      ? "border-primary text-primary"
                      : "border-transparent text-muted-foreground hover:text-foreground"
                  )}
                  onClick={() => setActiveTab("metadata")}
                >
                  <span className="flex items-center gap-2">
                    <Database className="h-4 w-4" />
                    Metadata
                  </span>
                </button>
              )}
            </div>
          </div>

          <div className="mt-0">
            {/* Profile Tab */}
            {activeTab === "profile" && (
              <div className="space-y-6">
                <div className="grid gap-6 md:grid-cols-3">
                  <div>
                    <h3 className="mb-4 text-sm font-medium text-muted-foreground">
                      Basic Information
                    </h3>
                    <dl className="space-y-3">
                      {{#fields}}
                      {{#unless isDate}}
                      {{#unless isStatus}}
                      {{#unless isId}}
                      {{#if isFirst}}
                      <div>
                        <dt className="text-sm font-medium">{{label}}</dt>
                        <dd className="mt-1 text-sm text-muted-foreground">
                          {formatFieldValue({{entityVar}}.{{name}})}
                        </dd>
                      </div>
                      {{else}}
                      {{#if isCodeField}}
                      <div>
                        <dt className="text-sm font-medium">{{label}}</dt>
                        <dd className="mt-1 text-sm text-muted-foreground">
                          {formatFieldValue({{entityVar}}.{{name}})}
                        </dd>
                      </div>
                      {{else}}
                      {{#if isDisplayField}}
                      <div>
                        <dt className="text-sm font-medium">{{label}}</dt>
                        <dd className="mt-1 text-sm text-muted-foreground">
                          {formatFieldValue({{entityVar}}.{{name}})}
                        </dd>
                      </div>
                      {{/if}}
                      {{/if}}
                      {{/if}}
                      {{/unless}}
                      {{/unless}}
                      {{/unless}}
                      {{/fields}}
                    </dl>
                  </div>

                  {{#if hasStatus}}
                  <div>
                    <h3 className="mb-4 text-sm font-medium text-muted-foreground">
                      Status
                    </h3>
                    <dl className="space-y-3">
                      <div>
                        <dt className="text-sm font-medium">Status</dt>
                        <dd className="mt-1">
                          <Badge variant={is{{EntityName}}Active ? "default" : "secondary"}>
                            {is{{EntityName}}Active ? "Active" : "Inactive"}
                          </Badge>
                        </dd>
                      </div>
                    </dl>
                  </div>
                  {{/if}}

                  <div>
                    <h3 className="mb-4 text-sm font-medium text-muted-foreground">
                      Timeline
                    </h3>
                    <dl className="space-y-3">
                      {{{entityVar}}.createdAt && (
                        <div>
                          <dt className="text-sm font-medium">Created</dt>
                          <dd className="mt-1 text-sm text-muted-foreground">
                            {formatDate({{entityVar}}.createdAt)}
                          </dd>
                        </div>
                      )}
                      {{{entityVar}}.updatedAt && (
                        <div>
                          <dt className="text-sm font-medium">Last Updated</dt>
                          <dd className="mt-1 text-sm text-muted-foreground">
                            {formatDate({{entityVar}}.updatedAt)}
                          </dd>
                        </div>
                      )}
                    </dl>
                  </div>
                </div>
              </div>
            )}

            {/* Metadata Tab */}
            {activeTab === "metadata" && (
              <div className="space-y-6">
                <Card>
                  <div className="p-4">
                    <pre className="text-xs overflow-auto">
                      {JSON.stringify({{entityVar}}, null, 2)}
                    </pre>
                  </div>
                </Card>
              </div>
            )}
          </div>
        </Tabs>
      </div>
    </Card>
  );
}
