/**
 * {{EntityName}} Hooks
 *
 * React Query hooks for {{entity-name}} operations
 * Provides data fetching, mutations, and query management
 */

import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import type {
  {{EntityName}},
  Create{{EntityName}}Input,
  Update{{EntityName}}Input,
  {{EntityName}}Filter,
} from "../types";
import type { Pagination, PaginatedResponse } from "@truths/shared";
import type {{{EntityName}}Service } from "./{{entity-name}}-service";

export interface Use{{EntityPlural}}Params {
  filter?: {{EntityName}}Filter;
  pagination?: Pagination;
}

export function use{{EntityPlural}}(service: {{EntityName}}Service, params?: Use{{EntityPlural}}Params) {
  const { filter, pagination } = params || {};

  return useQuery<PaginatedResponse<{{EntityName}}>>({
    queryKey: [
      "{{entity-plural}}",
      filter?.search,
{{#filterParams}}
      filter?.{{name}},
{{/filterParams}}
      pagination?.page,
      pagination?.pageSize,
    ],
    queryFn: () => {
      const skip = pagination ? (pagination.page - 1) * pagination.pageSize : 0;
      const limit = pagination?.pageSize || 50;

      return service.fetch{{EntityPlural}}({
        skip,
        limit,
        search: filter?.search,
{{#filterParams}}
        {{name}}: filter?.{{name}},
{{/filterParams}}
      });
    },
    staleTime: 5 * 60 * 1000,
  });
}

export function use{{EntityName}}(service: {{EntityName}}Service, {{entityName}}Id: string | null) {
  return useQuery<{{EntityName}}>({
    queryKey: ["{{entity-name}}", {{entityName}}Id],
    queryFn: () =>
      {{entityName}}Id ? service.fetch{{EntityName}}({{entityName}}Id) : Promise.resolve(null as any),
    enabled: !!{{entityName}}Id,
    staleTime: 5 * 60 * 1000,
  });
}

export function useCreate{{EntityName}}(service: {{EntityName}}Service) {
  const queryClient = useQueryClient();

  return useMutation<{{EntityName}}, Error, Create{{EntityName}}Input>({
    mutationFn: (input) => service.create{{EntityName}}(input),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["{{entity-plural}}"] });
    },
  });
}

export function useUpdate{{EntityName}}(service: {{EntityName}}Service) {
  const queryClient = useQueryClient();

  return useMutation<{{EntityName}}, Error, { id: string; input: Update{{EntityName}}Input }>({
    mutationFn: ({ id, input }) => service.update{{EntityName}}(id, input),
    onSuccess: (_data, variables) => {
      queryClient.invalidateQueries({ queryKey: ["{{entity-plural}}"] });
      queryClient.invalidateQueries({ queryKey: ["{{entity-name}}", variables.id] });
    },
  });
}

export function useDelete{{EntityName}}(service: {{EntityName}}Service) {
  const queryClient = useQueryClient();

  return useMutation<void, Error, string>({
    mutationFn: (id) => service.delete{{EntityName}}(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["{{entity-plural}}"] });
    },
  });
}
{{#if hasStatusActions}}

export function useLock{{EntityName}}(service: {{EntityName}}Service) {
  const queryClient = useQueryClient();

  return useMutation<{{EntityName}}, Error, string>({
    mutationFn: (id) => service.lock{{EntityName}}(id, 60),
    onSuccess: (_data, id) => {
      queryClient.invalidateQueries({ queryKey: ["{{entity-plural}}"] });
      queryClient.invalidateQueries({ queryKey: ["{{entity-name}}", id] });
    },
  });
}

export function useUnlock{{EntityName}}(service: {{EntityName}}Service) {
  const queryClient = useQueryClient();

  return useMutation<{{EntityName}}, Error, string>({
    mutationFn: (id) => service.unlock{{EntityName}}(id),
    onSuccess: (_data, id) => {
      queryClient.invalidateQueries({ queryKey: ["{{entity-plural}}"] });
      queryClient.invalidateQueries({ queryKey: ["{{entity-name}}", id] });
    },
  });
}

export function useActivate{{EntityName}}(service: {{EntityName}}Service) {
  const queryClient = useQueryClient();

  return useMutation<{{EntityName}}, Error, string>({
    mutationFn: (id) => service.activate{{EntityName}}(id),
    onSuccess: (_data, id) => {
      queryClient.invalidateQueries({ queryKey: ["{{entity-plural}}"] });
      queryClient.invalidateQueries({ queryKey: ["{{entity-name}}", id] });
    },
  });
}

export function useDeactivate{{EntityName}}(service: {{EntityName}}Service) {
  const queryClient = useQueryClient();

  return useMutation<{{EntityName}}, Error, string>({
    mutationFn: (id) => service.deactivate{{EntityName}}(id),
    onSuccess: (_data, id) => {
      queryClient.invalidateQueries({ queryKey: ["{{entity-plural}}"] });
      queryClient.invalidateQueries({ queryKey: ["{{entity-name}}", id] });
    },
  });
}
{{/if}}

